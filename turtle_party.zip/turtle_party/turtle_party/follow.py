#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from turtlesim.srv import Spawn
from geometry_msgs.msg import Twist
import tf2_ros
import tf_transformations
import math

class TurtleFollower(Node):

    def __init__(self):
        super().__init__('turtle_follower')

        self.declare_parameter('target_frame', 'turtle1')
        self.declare_parameter('turtle_name', 'turtle2')

        self.target_frame = self.get_parameter('target_frame').get_parameter_value().string_value
        self.turtle_name = self.get_parameter('turtle_name').get_parameter_value().string_value

        self.cmd_vel_pub = self.create_publisher(Twist, f'/{self.turtle_name}/cmd_vel', 10)

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.create_timer(0.1, self.follow_turtle)

        # Try to spawn the turtle
        self.spawn_turtle()

    def spawn_turtle(self):
        client = self.create_client(Spawn, 'spawn')
        while not client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for spawn service...')

        request = Spawn.Request()
        request.x = 4.0
        request.y = 2.0
        request.theta = 0.0
        request.name = self.turtle_name

        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        if future.result() is not None:
            self.get_logger().info(f"Spawned {future.result().name}")
        else:
            self.get_logger().info('Turtle might already exist.')

    def follow_turtle(self):
        try:
            trans = self.tf_buffer.lookup_transform(self.turtle_name, self.target_frame, rclpy.time.Time())
            dx = trans.transform.translation.x
            dy = trans.transform.translation.y

            angle_to_target = math.atan2(dy, dx)
            distance = math.sqrt(dx * dx + dy * dy)

            msg = Twist()
            msg.linear.x = 1.5 * distance
            msg.angular.z = 4.0 * angle_to_target

            self.cmd_vel_pub.publish(msg)

        except Exception as e:
            self.get_logger().warn(f'Could not transform: {e}')

def main(args=None):
    rclpy.init(args=args)
    node = TurtleFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
