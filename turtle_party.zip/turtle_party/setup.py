from setuptools import find_packages, setup

package_name = 'turtle_party'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/turtles_gone_wild.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='sam',
    maintainer_email='sampurnadhar.official@gmail.com',
    description='Turtle party follower package',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'follow = turtle_party.follow:main',
            'broadcaster = turtle_party.broadcaster:main',
        ],
    },
)


